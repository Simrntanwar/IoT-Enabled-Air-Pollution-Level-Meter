/*
 * Copyright (c) 2015-2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== httpget.c ========
 *  HTTP Client GET example application
 */

/* BSD support */
#include "string.h"
#include <ti/display/Display.h>
#include <ti/net/http/httpclient.h>
#include "semaphore.h"
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>


// Import ADC Driver definitions
#include <ti/drivers/ADC.h>
/* Driver configuration */
#include "ti_drivers_config.h"


/* POSIX Header files */
#include <pthread.h>

#define HOSTNAME              "https://blr1.blynk.cloud/"
///#define REQUEST_URI           "/external/api/update?token=pjWkyy-uyAW32Egx0HZzDDbHPy8YmChJ&V1=356"
#define REQUEST_URI           "/external/api/batch/update?token=Ss-a_uTmH0BvqzkSQzNTyGHe--EzPJbo&V0="
#define V1                    "&V1="
#define V2                    "&V2="
#define V3                    "&V3="
#define USER_AGENT            "HTTPClient (ARM; TI-RTOS)"
#define HTTP_MIN_RECV         (128)

/* ADC sample count */
#define ADC_SAMPLE_COUNT  (1)

#define THREADSTACKSIZE   (768)

#define ADC (4095.0)

#define SUB (1.0)
/// Atmospheric CO2 level for calibration purposes
#define ATMOCO2 (417.83)

/*Using the MQ-135 datasheet slope and calibrating for CO2*/

#define m_135 (-0.4594316186)
#define x_135 (2.30103)
#define y_135 (-0.09691)
#define t_fac_CO2 (1.05)
#define air_fac_CO2 (3.6333)
#define R0_135 (29.56949379*RL)
/// 16.20265278
/// 14.20752093

/*Using the MQ-4 datasheet slope and calibrating for CH4*/

#define m_4 (-0.3988062424)
#define x_4 (3)
#define y_4 (0)
#define t_fac_CH4 (1.05)
#define air_fac_CH4 (4.5)
#define R0_4 (10000*RL)
/// 0.6493764467
#define ATMOCH4 (1.9)
///
///
/*Using the MQ-7 datasheet slope and calibrating for CO*/
#define m_7 (-0.6527580092)
#define x_7 (2)
#define y_7 (0)
#define t_fac_CO (1.05)
#define air_fac_CO (4.5)
#define R0_7 (2.016*RL)
/// 0.6493764467
#define ATMOCO (2.5)


#define B (10.0)
#define RL (1)







/* ADC conversion result variables */
///uint16_t adcValue0[ADC_SAMPLE_COUNT];
uint16_t adc0;
uint16_t adc;
///uint32_t adcValue0MicroVolt[ADC_SAMPLE_COUNT];
uint32_t ppm0;
uint16_t adc1;
uint32_t ppm1;
///uint32_t adcValue1MicroVolt[ADC_SAMPLE_COUNT];
uint16_t adc2;
///uint32_t adcValue2MicroVolt[ADC_SAMPLE_COUNT];
uint32_t ppm2;

extern Display_Handle display;
extern sem_t ipEventSyncObj;
extern void printError(char *errString,
                       int code);






void *threadFxn0(void *arg0) /// MQ-135
{
    uint16_t     i;
    ADC_Handle   adc;
    ADC_Params   params;
    int_fast16_t res;

    ADC_Params_init(&params);
    adc = ADC_open(CONFIG_ADC_0, &params);

    if (adc == NULL) {
        Display_printf(display, 0, 0, "Error initializing CONFIG_ADC_0\n");
    }

    /* Blocking mode conversion */
   /// for (i = 0; i < ADC_SAMPLE_COUNT; i++) {
            res = ADC_convert(adc, &adc0);
            if (res == ADC_STATUS_SUCCESS) {

                ///adcValue0MicroVolt[i] = ADC_convertRawToMicroVolts(adc, adcValue0[i]);
                /*ppm1[i] = PARA * pow(((((ADC/adcValue1[i]) * VCC - SUB)*RLOAD)/RZERO), -PARB);*/




                Display_printf(display, 0, 0, "CONFIG_ADC_0 raw result: %d\n",
                               adc0);
               /* Display_printf(display, 0, 0, "CONFIG_ADC_0 convert result (%d): %d uV\n", i,
                    adcValue0MicroVolt[i]);*/
                Display_printf(display, 0, 0, "CONFIG_ADC_0 PPM result : %d\n",
                               ppm0);
            }
            else {
                Display_printf(display, 0, 0, "CONFIG_ADC_0 convert failed\n" );
            }
     ///   }
        ppm0 = pow(B,(((log10(((ADC/adc0)-SUB)*RL/R0_135)-y_135)/m_135) + x_135));
        ADC_close(adc);

        return (NULL);
    }

void *threadFxn1(void *arg0) /// MQ-7
{
    uint16_t     i;
    ADC_Handle   adc;
    ADC_Params   params;
    int_fast16_t res;

    ADC_Params_init(&params);
    adc = ADC_open(CONFIG_ADC_1, &params);

    if (adc == NULL) {
        Display_printf(display, 0, 0, "Error initializing CONFIG_ADC_0\n");
    }

    /* Blocking mode conversion */
   /// for (i = 0; i < ADC_SAMPLE_COUNT; i++) {
            res = ADC_convert(adc, &adc1);

            if (res == ADC_STATUS_SUCCESS) {

                ///adcValue0MicroVolt[i] = ADC_convertRawToMicroVolts(adc, adcValue0[i]);



                Display_printf(display, 0, 0, "CONFIG_ADC_1 raw result: %d\n",
                               adc1);
               /* Display_printf(display, 0, 0, "CONFIG_ADC_0 convert result (%d): %d uV\n", i,
                    adcValue0MicroVolt[i]);*/
                Display_printf(display, 0, 0, "CONFIG_ADC_1 PPM result : %d\n",
                               ppm1);
            }
            else {
                Display_printf(display, 0, 0, "CONFIG_ADC_1 convert failed\n" );
            }
     ///   }
        ppm1 = pow(B,(((log10(((ADC/adc1)-SUB)*RL/R0_7)-y_7)/m_7) + x_7));
        ADC_close(adc);

        return (NULL);
    }



void *threadFxn2(void *arg0) /// MQ-4
{
    uint16_t     i;
    ADC_Handle   adc;
    ADC_Params   params;
    int_fast16_t res;

    ADC_Params_init(&params);
    adc = ADC_open(CONFIG_ADC_2, &params);

    if (adc == NULL) {
        Display_printf(display, 0, 0, "Error initializing CONFIG_ADC_0\n");
    }

    /* Blocking mode conversion */
   /// for (i = 0; i < ADC_SAMPLE_COUNT; i++) {
            res = ADC_convert(adc, &adc2);
            if (res == ADC_STATUS_SUCCESS) {

                ///adcValue0MicroVolt[i] = ADC_convertRawToMicroVolts(adc, adcValue0[i]);


                Display_printf(display, 0, 0, "CONFIG_ADC_2 raw result: %d\n",
                               adc2);
               /* Display_printf(display, 0, 0, "CONFIG_ADC_0 convert result (%d): %d uV\n", i,
                    adcValue0MicroVolt[i]);*/
                Display_printf(display, 0, 0, "CONFIG_ADC_0 PPM result : %d\n",
                               ppm2);
            }
            else {
                Display_printf(display, 0, 0, "CONFIG_ADC_2 convert failed\n" );
            }
     ///   }
        ppm2 = pow(B,(((log10(((ADC/adc2)-SUB)*RL/R0_4)-y_4)/m_4) + x_4));

        ADC_close(adc);

        return (NULL);
    }




/*
 *  ======== httpTask ========
 *  Makes a HTTP GET request
 */
void* httpTask(void* pvParameters)
{


    pthread_t           thread0,thread1,thread2;
    pthread_attr_t      attrs;
    struct sched_param  priParam;
    int                 retc;
    int                 detachState;


    while(1){
    /* Call driver init functions */
    ADC_init();
    ///Display_init();
    /* Open the display for output */
    ///display = Display_open(Display_Type_UART, NULL);

    char URI[100];
    char URI1[100];
    char URI2[100];
    char URI3[100];
    bool moreDataFlag = false;
    char data[HTTP_MIN_RECV];
    int16_t ret = 0;
    int16_t len = 0;


    Display_printf(display, 0, 0, "Sending a HTTP GET request to '%s'\n",
                   HOSTNAME);

    HTTPClient_Handle httpClientHandle;
    int16_t statusCode;
    httpClientHandle = HTTPClient_create(&statusCode,0);
    if(statusCode < 0)
    {
        printError("httpTask: creation of http client handle failed",
                   statusCode);
    }

    ret =
        HTTPClient_setHeader(httpClientHandle,
                             HTTPClient_HFIELD_REQ_USER_AGENT,
                             USER_AGENT,strlen(USER_AGENT)+1,
                             HTTPClient_HFIELD_PERSISTENT);
    if(ret < 0)
    {
        printError("httpTask: setting request header failed", ret);
    }

    ret = HTTPClient_connect(httpClientHandle,HOSTNAME,0,0);
    if(ret < 0)
    {
        printError("httpTask: connect failed", ret);
    }




    /* Create application threads */
        pthread_attr_init(&attrs);

        detachState = PTHREAD_CREATE_DETACHED;
        /* Set priority and stack size attributes */
        retc = pthread_attr_setdetachstate(&attrs, detachState);
        if (retc != 0) {
            Display_printf(display,0,0,"pthread_attr_setdetachstate() failed");
        }

        retc |= pthread_attr_setstacksize(&attrs, THREADSTACKSIZE);
        if (retc != 0) {
            Display_printf(display,0,0,"pthread_attr_setstacksize() failed");
        }

        /* Create threadFxn0 thread */
        ///priParam.sched_priority = 1;
        /// pthread_attr_setschedparam(&attrs, &priParam);

        retc = pthread_create(&thread0, &attrs, threadFxn0, (void* )0);
        if (retc != 0) {
            Display_printf(display,0,0,"pthread_create() failed");
        }
        retc = pthread_create(&thread1, &attrs, threadFxn1, (void* )0);
                if (retc != 0) {
                    Display_printf(display,0,0,"pthread_create() failed");
                }
        retc = pthread_create(&thread2, &attrs, threadFxn2, (void* )0);
                if (retc != 0) {
                    Display_printf(display,0,0,"pthread_create() failed");
                }


        if (adc0 < 280){
            adc = 0;
        }
        if (adc0 >= 280 && adc0<400){
            adc = 1;
        }
        if (adc0 >= 400){
            adc = 2;
                }

    Display_printf(display, 0, 0, "%d%d%d\n", ppm0,ppm1,ppm2);

    sprintf(URI,"%s%d",REQUEST_URI,adc0);
    Display_printf(display, 0, 0, "URI:      %s\n", URI);


    sprintf(URI1,"%s%d%",V1,adc1);
    strcat(URI,URI1);
    Display_printf(display, 0, 0, "URI:      %s\n", URI);

    sprintf(URI2,"%s%d%\n",V2,adc2/5);
    strcat(URI,URI2);
    Display_printf(display, 0, 0, "URI:      %s\n", URI);

    sprintf(URI3,"%s%d%\n",V3,adc);
    strcat(URI,URI3);
    Display_printf(display, 0, 0, "URI:      %s\n", URI);



    ret =
        HTTPClient_sendRequest(httpClientHandle,HTTP_METHOD_GET,URI,
                               NULL,0,
                               0);
    if(ret < 0)
    {
        printError("httpTask: send failed", ret);
    }

    if(ret != HTTP_SC_OK)
    {
        printError("httpTask: cannot get status", ret);
    }

    Display_printf(display, 0, 0, "HTTP Response Status Code: %d\n", ret);

    len = 0;
    do
    {
        ret = HTTPClient_readResponseBody(httpClientHandle, data, sizeof(data),
                                          &moreDataFlag);
        if(ret < 0)
        {
            printError("httpTask: response body processing failed", ret);
        }
        Display_printf(display, 0, 0, "%.*s \r\n",ret,data);
        len += ret;
    }
    while(moreDataFlag);

    Display_printf(display, 0, 0, "Received %d bytes of payload\n", len);

    ret = HTTPClient_disconnect(httpClientHandle);
    if(ret < 0)
    {
        printError("httpTask: disconnect failed", ret);
    }

    HTTPClient_destroy(httpClientHandle);
    }

    return(0);
}
